﻿using FadakTahrir.Data;
using Quartz;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FadakTahrir.Jobs
{
    [DisallowConcurrentExecution]
    public class RemoveCartJob : IJob
    {
        ApplicationDbContext _context;
        public RemoveCartJob(ApplicationDbContext context)
        {
            _context = context;
        }
        public Task Execute(IJobExecutionContext context)
        {
            var orders = _context.Order.Where(o => !o.IsFinaly && o.CreateDate > DateTime.Now.AddHours(-24)).ToList();
            foreach (var order in orders)
            {
                var orderDetail = _context.OrderDetail.Where(od => od.OrderID == order.OrderID).ToList();
                foreach (var detail in orderDetail)
                {
                    _context.Remove(detail);
                }
                _context.Remove(order);
            }
            _context.SaveChanges();
            return Task.CompletedTask;
        }
    }
}
