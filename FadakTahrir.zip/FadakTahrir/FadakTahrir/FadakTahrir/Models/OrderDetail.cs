﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace FadakTahrir.Models
{
    public class OrderDetail
    {
        [Key]
        public int OrderDetailID { get; set; }
        [Required]
        public int OrderID { get; set; }
        [Required]
        public int Price { get; set; }
        [Required]
        public int Count { get; set; }

        [Required]
        public int ProductID { get; set; }

        public Order Order { get; set; }
        public virtual Product Product { get; set; }
    }
}
