﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace FadakTahrir.Models
{
    public class Order
    {
        [Key]
        public int OrderID { get; set; }
        [Required]
        public string UserID { get; set; }
        [Required]
        public DateTime CreateDate { get; set; }
        [Required]
        public int Sum { get; set; }
        
        public bool IsFinaly { get; set; }


        public string Address { get; set; }
        public string PhoneNumber { get; set; }
        public string MobileNumber { get; set; }




        public IList<OrderDetail> OrderDetails { get; set; }

    }
}
