﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace FadakTahrir.Models
{
    public class Group
    {
        [Key]
        public int ID { get; set; }

        [Display(Name = "نام گروه")]
        public string Name { get; set; }
        public virtual ICollection<SubGroup> SubGroup { get; set; }
    }
}