﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace FadakTahrir.Models
{
    public class SubGroup
    {
        [Key]
        public int ID { get; set; }
        [Display(Name="نام زیر گروه")]
        public string Name { get; set; }

        [ForeignKey("GroupId")]
        public int GroupId { get; set; }

        
        public virtual Group Group { get; set; }
        public virtual ICollection<Product> Product { get; set; }

    }
}