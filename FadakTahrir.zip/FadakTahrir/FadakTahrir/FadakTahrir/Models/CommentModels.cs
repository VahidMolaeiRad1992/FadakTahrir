﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace FadakTahrir.Models
{
    public class Comment
    {
        [Key]
        public int ID { get; set; }

        [Display(Name = "نام کاربری ")]
        
        public string UserName { get; set; }

        [Display(Name = "نام ")]
        [Required(ErrorMessage = "نام  را وارد کنید.")]
        public string Name { get; set; }

        [Display(Name = "متن ")]
        [Required(ErrorMessage = "متن را وارد کنید.")]
        public string CommentText { get; set; }



        
        public int ProductId { get; set; }

        [ForeignKey("ProductId")]
        public Product Product { get; set; }
    }
}
