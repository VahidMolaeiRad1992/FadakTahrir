﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace FadakTahrir.Models.ViewModels
{
    public class LoginViewModel
    {

        [Display(Name ="پست الکترونیک ")]
        [Required(ErrorMessage = "پست الکترونیک را وارد کنید.")]
        [EmailAddress(ErrorMessage = "پست الکترونیک را صحیح وارد نمایید.")]
        public string Email { get; set; }


        [Display(Name = "کلمه عبور ")]
        
        [Required(ErrorMessage = "کلمه عبور را صحیح وارد کنید.")]
        [DataType(DataType.Password)]
        public string Password { get; set; }

        [Display(Name ="مرا به خاطر بسپار!")]
        public bool RemmemberMe { get; set; }
    }
}
