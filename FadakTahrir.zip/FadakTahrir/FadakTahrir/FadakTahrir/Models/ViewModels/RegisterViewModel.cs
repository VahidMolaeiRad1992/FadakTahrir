﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace FadakTahrir.Models.ViewModels
{
    public class RegisterViewModel
    {
        [Display(Name ="پست الکترونیک ")]
        [Required(ErrorMessage = "پست الکترونیک را وارد کنید.")]
        [EmailAddress(ErrorMessage ="پست الکترونیک را صحیح وارد نمایید.")]
        public string Email { get; set; }

        [Display(Name = "کلمه عبور ")]
        [Required(ErrorMessage = "کلمه عبور را وارد کنید.")]
        [DataType(DataType.Password)]
        public string Password { get; set; }

        [Display(Name = "تکرار کلمه عبور ")]
        [Required(ErrorMessage = "کلمه عبور را وارد کنید.")]
        [DataType(DataType.Password)]
        [Compare("Password",ErrorMessage ="کلمه عبور و تکرار آن یکسان نمی باشد.")]
        public string ConfirmPassword { get; set; }


        [Display(Name = "نام و نام خانوادگی")]
        [Required(ErrorMessage = "نام و نام خوانوادگی را وارد کنید.")]
        public string FullName { get; set; }
    }
}
