﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace FadakTahrir.Models.ViewModels
{
    public class ProfileViewModel
    {
        [Key]
        public string ID { get; set; }

        [Display(Name ="نام و نام خانوادگی ")]
        [Required(ErrorMessage = "نام و نام خانوادگی.")]
        public string FullName { get; set; }

      
        public string Email { get; set; }

        [Display(Name = "آدرس ")]
        [Required(ErrorMessage = "آدرس را وارد کنید.")]
        public string Address { get; set; }

        [Display(Name = "شماره موبایل ")]
        [Required(ErrorMessage = "شماره موبایل را وارد کنید.")]
        public string MobileNumber{ get; set; }

        [Display(Name = "شماره تلفن ")]
        [Required(ErrorMessage = "شماره تلفن را وارد کنید.")]
        public string PhoneNumber { get; set; }


    }
}
