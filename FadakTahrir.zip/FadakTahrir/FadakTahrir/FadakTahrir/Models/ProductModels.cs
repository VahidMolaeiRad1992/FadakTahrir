﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace FadakTahrir.Models
{
    public class Product
    {
        [Key]
        public int ID { get; set; }

        [Display(Name = "نام")]
        public string Name { get; set; }

        [Display(Name = "قیمت")]
        public int Price { get; set; }

        [Display(Name="تصویر")]
        public string Image { get; set; }

        [Display(Name = "توضیحات")]
        public string Description { get; set; }

       
        public int SubGroupId { get; set; }

        
        [ForeignKey("SubGroupId")]
        public virtual SubGroup SubGroup { get; set; }
        public IList<OrderDetail> OrderDetails { get; set; }
        public IList<Comment> Comments { get; set; }



    }
}