﻿using FadakTahrir.Data;
using FadakTahrir.Models.ViewModels;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace FadakTahrir.Components
{
    public class CartComponent:ViewComponent
    {
        ApplicationDbContext _context;
        public CartComponent(ApplicationDbContext context)
        {
            _context = context;        
        }

        public async Task<IViewComponentResult> InvokeAsync()
        {
            List<ShowCartViewModel> _list = new List<ShowCartViewModel>();

            if (User.Identity.IsAuthenticated)
            {
                string CurrentUserID =HttpContext.User.FindFirstValue(ClaimTypes.Name);
                var order = _context.Order.SingleOrDefault(o => o.UserID == CurrentUserID && !o.IsFinaly);
                if (order !=null)
                {
                    var details = _context.OrderDetail.Where(od => od.OrderID == order.OrderID).ToList();
                    foreach (var item in details)
                    {
                        var product = _context.Product.Find(item.ProductID);
                        _list.Add(new ShowCartViewModel() 
                        {
                            Count=item.Count,
                            Image=product.Image,
                            Name=product.Name
                        });
                    }
                    
                }

            }

            
            return View("/Views/shared/_ShowCart.cshtml", _list);
        }

    }
}
