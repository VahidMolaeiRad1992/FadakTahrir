﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FadakTahrir.Models.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;

namespace FadakTahrir.Controllers
{
    public class AdminController : Controller
    {
        private readonly RoleManager<IdentityRole> roleManager;

        public AdminController(RoleManager<IdentityRole> roleManager)
        {
            this.roleManager = roleManager;
        }
        [Authorize(Roles ="Admin")]
        //[Authorize(Roles ="Admin")]
        public IActionResult Index()
        {
            return View();
        }


        
       
    }
}