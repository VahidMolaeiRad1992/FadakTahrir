﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using FadakTahrir.Data;
using FadakTahrir.Models;
using Microsoft.AspNetCore.Authorization;

namespace FadakTahrir.Controllers
{
    [Authorize(Roles ="Admin")]
    public class GroupsController : Controller
    {
        private readonly ApplicationDbContext _context;

        public GroupsController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: Groups
        public async Task<IActionResult> Index()
        {
            return View(await _context.Group.ToListAsync());
        }

      

        // GET: Groups/Create
        public IActionResult AddOrEdit(int id=0)
        {
            if (id == 0)
                return View(new Group { });
            else
                return View(_context.Group.Find(id));
        }

        // POST: Groups/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> AddOrEdit([Bind("ID,Name")] Group @group)
        {
            if (ModelState.IsValid)
            {
                if (@group.ID == 0)
                    _context.Add(@group);
                else
                    _context.Update(group);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(@group);
        }

       
        // GET: Groups/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            var groups = await _context.Group.FindAsync(id);
            _context.Remove(groups);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

       

        private bool GroupExists(int id)
        {
            return _context.Group.Any(e => e.ID == id);
        }
    }
}
