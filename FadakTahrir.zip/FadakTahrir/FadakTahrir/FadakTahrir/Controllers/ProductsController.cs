﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using FadakTahrir.Data;
using FadakTahrir.Models;
using Microsoft.AspNetCore.Hosting;
using System.IO;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Authorization;
using FadakTahrir.Models.ViewModels;

namespace FadakTahrir.Controllers
{
    public class ProductsController : Controller
    {
        private readonly ApplicationDbContext _context;
        private IHostingEnvironment _environment;
        private readonly UserManager<ApplicationUser> userManager;
        public ProductsController(ApplicationDbContext context, IHostingEnvironment environment,
                                  UserManager<ApplicationUser> userManager)
        {
            this.userManager = userManager;
            _context = context;
            _environment = environment;
        }

        [Authorize(Roles = "Admin")]
        // GET: Products
        public async Task<IActionResult> Admin_Index()
        {
            var applicationDbContext = _context.Product.Include(p => p.SubGroup);
            return View(await applicationDbContext.ToListAsync());
        }

        [AllowAnonymous]
        public async Task<IActionResult>Customer_Index(int? pageNumber)
        {
            var applicationDbContext = _context.Product.Include(p => p.SubGroup);



            int pageSize =9;
            return View(await PaginatedList<Product>.CreateAsync( applicationDbContext.AsNoTracking(), pageNumber ?? 1, pageSize));
           
        }


        [AllowAnonymous]
        public async Task<IActionResult> Product_Index(int? pageNumber,int? id)
        {
            var applicationDbContext = _context.Product.Include(p => p.SubGroup).ThenInclude(u => u.Group)
               .Where(x => x.SubGroup.GroupId == id);

            if (id == null)
            {
                applicationDbContext = _context.Product.Include(p => p.SubGroup);
            }


           
            ViewBag.Groups = _context.Group.ToList();

           




            int pageSize = 9;
            return View(await PaginatedList<Product>.CreateAsync(applicationDbContext.AsNoTracking(), pageNumber ?? 1, pageSize));

        }




        public async Task<IActionResult> Group_Index(int? group, int? subgroup)
        {
            //var applicationDbContext = _context.Product.Include(p => p.SubGroup);
            var applicationDbContext = _context.Product.Include(p => p.SubGroup).Where(x => x.SubGroup.GroupId == group);
            return View(await applicationDbContext.ToListAsync());

        }




        [AllowAnonymous]
        // GET: Products/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var product = await _context.Product
                .Include(p => p.SubGroup).Include(p=>p.Comments)
                .FirstOrDefaultAsync(m => m.ID == id);
            if (product == null)
            {
                return NotFound();
            }
            ViewBag.comments = _context.Comment.Where(x => x.ProductId == id).ToList();
            return View(product);
        }



        [Authorize(Roles = "Admin")]
        // GET: Products/Create
        public IActionResult AddOrEdit(int id=0)
        {
            ViewData["SubGroupId"] = new SelectList(_context.SubGroup, "ID", "Name");
            if (id == 0)
                return View(new Product { });
            else
                return View(_context.Product.Find(id));
        }

        [Authorize(Roles = "Admin")]
        // POST: Products/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> AddOrEdit([Bind("ID,Name,Price,Image,Description,SubGroupId")] Product product, IFormFile productimage,string imagebeforeedit)
        {
            if (ModelState.IsValid)
            {
                var files = HttpContext.Request.Form.Files;
                foreach (var Image in files)
                {
                    if (Image != null && Image.Length > 0)
                    {
                        var file = Image;
                        //There is an error here
                        var uploads = Path.Combine(_environment.WebRootPath, "uploads\\img");
                        if (file.Length > 0)
                        {
                            var fileName = Guid.NewGuid().ToString().Replace("-", "") + Path.GetExtension(file.FileName);
                            using (var fileStream = new FileStream(Path.Combine(uploads, fileName), FileMode.Create))
                            {
                                await file.CopyToAsync(fileStream);
                                product.Image = "/Uploads/img/" + fileName;
                            }

                        }
                    }


                }
                if (product.ID == 0)
                    _context.Add(product);
                else
                {
                    product.Image = imagebeforeedit;
                    _context.Update(product);
                }
                 
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Admin_Index));
            }
            ViewData["SubGroupId"] = new SelectList(_context.SubGroup, "ID", "Name", product.SubGroupId);
            return View(product);

        }

        [Authorize(Roles = "Admin")]
        // GET: Products/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            var product = await _context.Product.FindAsync(id);
            _context.Product.Remove(product);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Admin_Index));

        }




        //Add Comment
       [AllowAnonymous]
        [HttpPost]
        public ActionResult AddComment(string name, string email, string comment, int pid)
        {
            Comment cm = new Comment();
            if (User.Identity.IsAuthenticated)
            {
                cm.Name = userManager.Users.Where(x => x.UserName == User.Identity.Name).Select(s => s.FullName).FirstOrDefault();
                cm.UserName = User.Identity.Name;
            }
            else
            {
                cm.Name = name;
                cm.UserName = email;
            }
               
                cm.CommentText = comment;
                cm.ProductId = pid;

            _context.Comment.Add(cm);
            _context.SaveChanges();

            return RedirectToAction("Details", new { id = pid });
        }




        private bool ProductExists(int id)
        {
            return _context.Product.Any(e => e.ID == id);
        }
    }

   
}
