﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FadakTahrir.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace FadakTahrir.Controllers
{
    
    public class SearchController : Controller
    {
        private readonly ApplicationDbContext _context;

        public SearchController(ApplicationDbContext context)
        {
            _context = context;
        }

        [HttpPost]
        public async Task<IActionResult> Index(string searchString)
        {
            ViewData["CurrentFilter"] = searchString;
            var model = _context.Product.Where(s => s.Name.Contains(searchString));
            
            return View(await model.AsNoTracking().ToListAsync());

          
        }




        


    }
}