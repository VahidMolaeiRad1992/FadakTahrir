﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;
using FadakTahrir.Data;
using FadakTahrir.Models;
using FadakTahrir.Models.ViewModels;
using ZarinpalSandbox;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;

namespace FadakTahrir.Controllers
{
    public class OrdersController : Controller
    {
        private ApplicationDbContext _context;
       
        private readonly UserManager<ApplicationUser> userManager;

        public OrdersController(ApplicationDbContext contex , UserManager<ApplicationUser> userManager)
        {
            _context = contex;
            this.userManager = userManager;
        }

        [Authorize]
        public IActionResult AddToCart(int id)
        {
            string CurrentUserID = User.FindFirstValue(ClaimTypes.Name);

            Order order = _context.Order.SingleOrDefault(o => o.UserID == CurrentUserID && !o.IsFinaly);

            if (order == null)
            {
                order = new Order()
                {
                    UserID = CurrentUserID,
                    CreateDate = DateTime.Now,
                    IsFinaly = false,
                    Sum = 0
                };
                _context.Order.Add(order);
                _context.OrderDetail.Add(new OrderDetail()
                {
                    OrderID = order.OrderID,
                    Count = 1,
                    Price = _context.Product.Find(id).Price,
                    ProductID=id
                    
                });
                _context.SaveChanges();
            }
            else
            {
                var details = _context.OrderDetail.SingleOrDefault(d => d.OrderID == order.OrderID && d.ProductID == id);
                if (details == null)
                {
                    _context.OrderDetail.Add(new OrderDetail()
                    {
                        OrderID = order.OrderID,
                        Count = 1,
                        Price = _context.Product.Find(id).Price,
                        ProductID = id
                    });
                }
                else
                {
                    details.Count += 1;
                    _context.Update(details);
                }

                _context.SaveChanges();
            }
            UpdateSumOrder(order.OrderID);
            return Redirect("/");

        }



        public IActionResult ShowOrder()
        {
            string CurrentUserID = User.FindFirstValue(ClaimTypes.Name);
            Order order = _context.Order.SingleOrDefault(o => o.UserID == CurrentUserID && !o.IsFinaly);
            List<ShowOrderViewModel> _list = new List<ShowOrderViewModel>();

            if (order != null)
            {
                var details = _context.OrderDetail.Where(od => od.OrderID == order.OrderID).ToList();
                foreach (var item in details)
                {
                    var product = _context.Product.Find(item.ProductID);
                    _list.Add(new ShowOrderViewModel()
                    {
                        Count = item.Count,
                        Image = product.Image,
                        Name = product.Name,
                        Price=item.Price,
                        Sum= (item.Count*item.Price),
                        OrderDetailId=item.OrderDetailID
                    });
                }

            }
            UpdateSumOrder(order.OrderID);
            //_context.Order.Update(order);
            return View(_list);
        }

        public async Task<IActionResult> Delete(int? id)
        {
            var orderDetail = await _context.OrderDetail.FindAsync(id);
            _context.Remove(orderDetail);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(ShowOrder));
        }


        public async Task<IActionResult> Command(int id, string command)
        {

            var orderDetail = await _context.OrderDetail.FindAsync(id);

            switch (command)
            {
                case "up":
                    {
                        orderDetail.Count += 1;
                        _context.Update(orderDetail);
                        break;
                    }
                case "down":
                    {
                        orderDetail.Count -= 1;
                        if (orderDetail.Count == 0)
                        {
                            _context.Remove(orderDetail);
                        }
                        else
                        {
                            _context.Update(orderDetail);

                        }
                        break;
                    }
                default:
                    break;
            }
           

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(ShowOrder));
        }




        public IActionResult Payment()
        {
            var order = _context.Order.SingleOrDefault(o => !o.IsFinaly);
            if (order==null)
            {
                return NotFound();
            }
            var payment = new Payment(order.Sum);
            var res = payment.PaymentRequest($"پرداخت شماره فاکتور{order.OrderID}", "https://localhost:44352/Home/OnlinePayment/"+ order.OrderID,"Vahid@gmail.com","09189136764");
            if (res.Result.Status==100)
            {
                return Redirect("https://sandbox.zarinpal.com/pg/StartPay/" + res.Result.Authority); 
            }
            else
            {
                return BadRequest();
            }
            
        }

        [HttpGet]
        public IActionResult CompleteOrders()
        {

            return View();

        }
        [HttpPost]
        public IActionResult CompleteOrders(OrderViewModel model)
        {
            string CurrentUserID = User.FindFirstValue(ClaimTypes.Name);
            var user = userManager.Users.Where(x => x.UserName == User.Identity.Name).FirstOrDefault();
            Order order = _context.Order.SingleOrDefault(o => o.UserID == CurrentUserID && !o.IsFinaly);
            var details = _context.OrderDetail.Where(od => od.OrderID == order.OrderID).ToList();


            order.Address = model.Address;
            order.MobileNumber = model.MobileNumber;
            order.PhoneNumber = model.PhoneNumber;
            order.UserID = CurrentUserID;
            //int total = 0;
            //foreach (var item in details)
            //{
            //    total = item.Count * item.Price;
            //}
            //order.Sum += total;
            _context.Order.Update(order);
            _context.SaveChanges();
            return RedirectToAction("Complete");

        }
            public IActionResult Complete()
        {
           
            return View();
        }


        public void UpdateSumOrder(int orderId)
        {
            var order = _context.Order.Find(orderId);
            order.Sum = _context.OrderDetail.Where(o => o.OrderID == order.OrderID).Select(d => d.Count * d.Price).Sum();
           

            _context.Update(order);
            _context.SaveChanges();
        }


        public IActionResult UserOrder_Index()
        {
            var userOrder = _context.Order.Where(x => x.UserID == User.Identity.Name).ToList();
            return View(userOrder);
        }

        public IActionResult UserOrderDetail_Index(int id)
        {
            var userOrder = _context.OrderDetail.Where(x => x.OrderID == id).ToList();

            var userdetail=_context.OrderDetail.Include(p => p.Order).Include(p => p.Product)
                .Where(m => m.OrderID == id);
            return View(userdetail);
        }

        [Authorize(Roles ="Admin")]
        public IActionResult AdminOrder_Index()
        {
            var orders = _context.Order.ToList();
            return View(orders);
        }

        [Authorize(Roles = "Admin")]
        public IActionResult AdminOrderDetail_Index(int id)
        {
            var userOrder = _context.OrderDetail.Where(x => x.OrderID == id).ToList();

            var userdetail = _context.OrderDetail.Include(p => p.Order).Include(p => p.Product)
                .Where(m => m.OrderID == id);
            return View(userdetail);
        }




    }

    
}