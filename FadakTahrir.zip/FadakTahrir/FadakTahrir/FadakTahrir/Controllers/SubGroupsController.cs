﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using FadakTahrir.Data;
using FadakTahrir.Models;
using Microsoft.AspNetCore.Authorization;

namespace FadakTahrir.Controllers
{
    [Authorize(Roles = "Admin")]
    public class SubGroupsController : Controller
    {
        private readonly ApplicationDbContext _context;

        public SubGroupsController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: SubGroups
        public async Task<IActionResult> Index()
        {
            var applicationDbContext = _context.SubGroup.Include(s => s.Group);
            return View(await applicationDbContext.ToListAsync());
        }

       
        // GET: SubGroups/Create
        public IActionResult AddOrEdit(int id=0)
        {
            ViewData["GroupId"] = new SelectList(_context.Group, "ID", "Name");
            if (id == 0)
                return View(new SubGroup { });
            else
                return View(_context.SubGroup.Find(id));
        }

        // POST: SubGroups/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> AddOrEdit([Bind("ID,Name,GroupId")] SubGroup subGroup)
        {
            if (ModelState.IsValid)
            {
                if (subGroup.ID == 0)
                    _context.Add(subGroup);
                else
                    _context.Update(subGroup);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["GroupId"] = new SelectList(_context.Group, "ID", "Name", subGroup.GroupId);
            return View(subGroup);
        }

        // GET: SubGroups/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var subGroup = await _context.SubGroup.FindAsync(id);
            if (subGroup == null)
            {
                return NotFound();
            }
            ViewData["GroupId"] = new SelectList(_context.Group, "ID", "ID", subGroup.GroupId);
            return View(subGroup);
        }

    
        // GET: SubGroups/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            var subgroup = await _context.SubGroup.FindAsync(id);
            _context.Remove(subgroup);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

       

        private bool SubGroupExists(int id)
        {
            return _context.SubGroup.Any(e => e.ID == id);
        }
    }
}
