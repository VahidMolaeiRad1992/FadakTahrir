﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using FadakTahrir.Models.ViewModels;
using Microsoft.AspNetCore.Identity;
using FadakTahrir.Models;
using FadakTahrir.Data;
using Microsoft.EntityFrameworkCore;

namespace FadakTahrir.Controllers
{
    public class AccountController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly UserManager<ApplicationUser> userManager;
        private readonly SignInManager<ApplicationUser> signInManager;

        public AccountController(UserManager<ApplicationUser> userManager,
                                 SignInManager<ApplicationUser> signInManager,
                                  ApplicationDbContext _context)
        {
            this.userManager = userManager;
            this.signInManager = signInManager;
            this._context = _context;
        }

        [AllowAnonymous]
        [HttpGet]
        public IActionResult Register()
        {
            return View();
        }
        [AllowAnonymous]
        [HttpPost]
        public async  Task<IActionResult> Register(RegisterViewModel model)
        {
            if (ModelState.IsValid)
            {
                var user = new ApplicationUser{UserName=model.Email,Email=model.Email,FullName=model.FullName};
                var result=await userManager.CreateAsync(user, model.Password);
                if (result.Succeeded)
                {
                    await signInManager.SignInAsync(user, isPersistent: false);
                    return RedirectToAction("Index", "Home");
                }
                foreach (var error in result.Errors)
                {
                    ModelState.AddModelError("", error.Description);
                }
            }
            return View(model);
        }



        [AllowAnonymous]
        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }
        [AllowAnonymous]
        [HttpPost]
        public async Task<IActionResult> Login(LoginViewModel model)
        {
            if (ModelState.IsValid)
            {
              
                var result = await signInManager.PasswordSignInAsync
                    (model.Email,model.Password,model.RemmemberMe,false);
                if (result.Succeeded)
                {
                   
                    return RedirectToAction("Index", "Home");
                }
                
                 ModelState.AddModelError(string.Empty,"تلاش ناموفق ");
                
            }
            return View(model);
        }

        public IActionResult DetailProfile()
        {
            string CurrentId = User.Identity.Name;
            var user = _context.Users.FirstOrDefault(x => x.UserName == CurrentId);
            var viewmodel = new ProfileViewModel();

            viewmodel.FullName = user.FullName;
            viewmodel.Address = user.Address;
            viewmodel.Email = user.Email;
            viewmodel.MobileNumber = user.MobileNumber;
            viewmodel.PhoneNumber = user.PhoneNumber;

            return View(viewmodel);

        }

        public IActionResult EditProfile()
        {
            string CurrentId = User.Identity.Name;
            var user = _context.Users.FirstOrDefault(x => x.UserName == CurrentId);
            var viewmodel = new ProfileViewModel();

            viewmodel.FullName = user.FullName;
            viewmodel.Address = user.Address;
            viewmodel.Email = user.Email;
            viewmodel.MobileNumber = user.MobileNumber;
            viewmodel.PhoneNumber = user.PhoneNumber;

            return View(viewmodel);
        }

        [HttpPost]
        public IActionResult EditProfile(ProfileViewModel profileViewModel)
        {
            string CurrentId = User.Identity.Name;
            var user = _context.Users.FirstOrDefault(x => x.UserName == CurrentId);


            user.FullName = profileViewModel.FullName;
            user.Address=profileViewModel.Address;
           
            user.MobileNumber=profileViewModel.MobileNumber;
            user.PhoneNumber=profileViewModel.PhoneNumber;

            _context.Entry(user).State = EntityState.Modified;
            _context.SaveChanges();
            return RedirectToAction("DetailProfile");
        }


    }
}