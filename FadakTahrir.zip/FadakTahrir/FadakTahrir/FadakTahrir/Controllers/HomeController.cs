﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using FadakTahrir.Models;
using FadakTahrir.Data;
using ZarinpalSandbox;
using Microsoft.AspNetCore.Authorization;
using Microsoft.EntityFrameworkCore;

namespace FadakTahrir.Controllers
{
    [AllowAnonymous]
    public class HomeController : Controller
    {
        private  ApplicationDbContext _context;


        public HomeController(ApplicationDbContext contex)
        {
            _context = contex;
        }
        public async Task< IActionResult> Index(int? pageNumber)
        {
            var applicationDbContext = _context.Product.Include(p => p.SubGroup);


            int pageSize = 12;
            return View(await PaginatedList<Product>.CreateAsync(applicationDbContext.AsNoTracking(), pageNumber ?? 1, pageSize));



        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        
        public IActionResult _nav_partial(int? pageNumber, int? id)
        {
            var applicationDbContext = _context.Product.Include(p => p.SubGroup).ThenInclude(u => u.Group)
              .Where(x => x.SubGroup.GroupId == id);
            ViewBag.Groups = _context.Group.ToList();

            
            return View(applicationDbContext.ToList());

        }

        public IActionResult OnlinePayment(int id)
        {

            if (HttpContext.Request.Query["Status"]!="" &&
                HttpContext.Request.Query["Status"].ToString().ToLower() == "ok" &&
                HttpContext.Request.Query["Authority"] != "")
            {
                string authority = HttpContext.Request.Query["Authority"].ToString();
                var order = _context.Order.Find(id);
                var payment = new Payment(order.Sum);
                var res = payment.Verification(authority).Result;
                if (res.Status==100)
                {
                    order.IsFinaly = true;
                    _context.Order.Update(order);
                    _context.SaveChanges();
                    ViewBag.code = res.RefId;
                    return View();

                }
            }

            return NotFound();
        }
    }
}
